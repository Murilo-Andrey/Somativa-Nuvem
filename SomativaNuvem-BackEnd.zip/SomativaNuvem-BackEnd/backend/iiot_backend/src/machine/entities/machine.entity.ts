export class Machine {}
