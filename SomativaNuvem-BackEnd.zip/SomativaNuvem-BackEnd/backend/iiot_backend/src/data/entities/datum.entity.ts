export class Datum {}
