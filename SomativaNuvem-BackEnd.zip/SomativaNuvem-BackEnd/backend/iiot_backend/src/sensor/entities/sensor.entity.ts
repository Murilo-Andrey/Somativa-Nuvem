export class Sensor {}
